﻿public enum CollectibleSpawnPointEnum
{
    TOPO_ESQUERDA = 0,
    TOPO_MEIO = 1,
    TOPO_DIREITA = 2,
    MEIO_ESQUERDA = 3,
    MEIO_MEIO = 4,
    MEIO_DIREITA = 5,
    BAIXO_ESQUERDA = 6,
    BAIXO_MEIO = 7,
    BAIXO_DIREITA = 8
}
