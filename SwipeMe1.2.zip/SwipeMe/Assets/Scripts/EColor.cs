﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EColor
{
    RED = 0,
    GREEN = 1,
    BLUE = 2,
    WHITE = 3,
    RAINBOW = 4
}
