﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Foo : MonoBehaviour
{
    private PlayerMovement pm;
	public static SpriteRenderer spr;

    void Awake()
    {
        pm = GetComponentInParent<PlayerMovement>();
		spr = GetComponent<SpriteRenderer> ();
    }

    public void BaseMovement()
    {
        pm.BroadcastMessage("Move");
    }

}
